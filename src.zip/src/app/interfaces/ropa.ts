export interface Ropa{

    id:string;
    producto:string;
    talla:string;
    color:string;
    precio:string;

}