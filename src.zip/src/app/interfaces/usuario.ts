export interface Usuario{

    id:string;
    usuario:string;
    nombre:string;
    correo:string;
    contrasena:string;

}