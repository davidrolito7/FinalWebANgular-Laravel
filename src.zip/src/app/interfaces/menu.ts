export interface Menu{
    nombre: String;
    redirec: String;
}